const api = globalThis.browser ?? globalThis.chrome;
const status = document.getElementById("status");

api.runtime.sendMessage({ type: "aura-ping" }).then(response => {
    status.textContent = response?.connected
        ? "Connected. Supports Google Forms and Firebase Realtime Database."
        : response?.error || "Pair the extension with AURA.";
}).catch(error => {
    status.textContent = `AURA is not connected: ${error.message}`;
});

document.getElementById("optionsButton").addEventListener("click", () => {
    api.runtime.openOptionsPage();
});
