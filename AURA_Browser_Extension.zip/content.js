(() => {
    "use strict";
    const api = globalThis.browser ?? globalThis.chrome;

    let lastRequestId = null;
    let capturedUrl = null;
    let questionElements = new Map();
    let polling = false;

    function textOf(element) {
        return (element?.getAttribute("aria-label") || element?.innerText || element?.textContent || "")
            .replace(/\s+/g, " ")
            .trim();
    }

    function questionBlocks() {
        return Array.from(document.querySelectorAll('[role="listitem"]'))
            .filter(block => block.querySelector('[role="radio"], [role="checkbox"], input:not([type="hidden"]), textarea, select'));
    }

    function extractForm(requestId) {
        const blocks = questionBlocks();
        questionElements = new Map();
        const questions = blocks.map((block, index) => {
            const id = `q${index + 1}`;
            const heading = block.querySelector('[role="heading"], .M7eMe, [data-params]');
            const controls = Array.from(block.querySelectorAll(
                '[role="radio"], [role="checkbox"], input:not([type="hidden"]), textarea, select'
            ));
            const optionControls = controls.filter(control =>
                ["radio", "checkbox"].includes(control.getAttribute("role")) ||
                ["radio", "checkbox"].includes(control.type)
            );
            const options = [...new Set(optionControls.map(textOf).filter(Boolean))];
            let inputType = options.length
                ? (optionControls.some(control => control.getAttribute("role") === "checkbox" || control.type === "checkbox")
                    ? "checkbox"
                    : "radio")
                : controls[0]?.tagName.toLowerCase() || "text";
            const text = textOf(heading) || textOf(block).slice(0, 2000);
            questionElements.set(id, { block, controls, options });
            return { id, text, options, input_type: inputType };
        }).filter(question => question.text);

        lastRequestId = requestId;
        capturedUrl = location.href;
        return {
            request_id: requestId,
            url: location.href,
            title: document.title,
            questions
        };
    }

    function setInputValue(element, value) {
        const prototype = element instanceof HTMLTextAreaElement
            ? HTMLTextAreaElement.prototype
            : element instanceof HTMLSelectElement
                ? HTMLSelectElement.prototype
                : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
        if (setter) setter.call(element, value);
        else element.value = value;
        element.dispatchEvent(new Event("input", { bubbles: true }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
    }

    function matchOption(control, answer) {
        const label = textOf(control).toLocaleLowerCase();
        const expected = answer.toLocaleLowerCase();
        return label === expected || control.getAttribute("data-value")?.toLocaleLowerCase() === expected;
    }

    function fillOneQuestion(answer) {
        const target = questionElements.get(answer.id);
        if (!target) return false;
        const value = answer.answer.trim();
        if (!value) return true;

        if (target.options.length) {
            const matched = target.controls.filter(control => matchOption(control, value));
            if (!matched.length) return false;
            matched.forEach(control => control.click());
            return true;
        }

        const field = target.controls.find(control =>
            control instanceof HTMLInputElement ||
            control instanceof HTMLTextAreaElement ||
            control instanceof HTMLSelectElement
        );
        if (!field) return false;
        if (field instanceof HTMLSelectElement) {
            const option = Array.from(field.options).find(item =>
                item.textContent.trim().toLocaleLowerCase() === value.toLocaleLowerCase()
            );
            if (!option) return false;
            setInputValue(field, option.value);
        } else {
            field.focus();
            setInputValue(field, value);
            field.blur();
        }
        return true;
    }

    async function runFillJob(job) {
        if (
            job.request_id !== lastRequestId ||
            capturedUrl !== location.href ||
            job.url !== location.href
        ) {
            await reportResult(job.request_id, "failed", "The active Google Form changed; scan it again before filling.");
            return;
        }

        const failures = (job.answers || [])
            .filter(answer => !fillOneQuestion(answer))
            .map(answer => answer.id);
        if (failures.length) {
            await reportResult(job.request_id, "failed", `Could not safely match these form fields: ${failures.join(", ")}.`);
            return;
        }

        if (!job.submit) {
            await reportResult(job.request_id, "filled", "Reviewed answers were filled. The form was not submitted.");
            return;
        }

        const submitButton = Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"]'))
            .find(button => textOf(button).toLocaleLowerCase() === "submit" && !button.disabled);
        if (!submitButton) {
            await reportResult(job.request_id, "failed", "Answers were filled, but a visible Submit button could not be found.");
            return;
        }
        await reportResult(job.request_id, "submitted", "Clicked the Google Forms Submit button.");
        submitButton.click();
    }

    async function pollAura() {
        if (polling || document.visibilityState !== "visible") return;
        polling = true;
        try {
            const response = await api.runtime.sendMessage({ type: "aura-poll" });
            if (response?.job) {
                const job = response.job;
                if (job.action === "capture_form") {
                    const payload = extractForm(job.request_id);
                    if (!payload.questions.length) {
                        await reportResult(job.request_id, "failed", "No supported Google Forms questions were found on the active tab.");
                    } else {
                        const result = await api.runtime.sendMessage({
                            type: "aura-capture",
                            payload
                        });
                        if (result?.error) {
                            await reportResult(job.request_id, "failed", result.error);
                        }
                    }
                } else if (job.action === "fill_form") {
                    await runFillJob(job);
                }
            } else if (response?.error) {
                console.debug("AURA browser connector:", response.error);
            }
        } catch (error) {
            console.debug("AURA browser connector:", error);
        } finally {
            polling = false;
        }
    }

    async function reportResult(requestId, status, message) {
        try {
            await api.runtime.sendMessage({
                type: "aura-result",
                payload: { request_id: requestId, status, message }
            });
        } catch (error) {
            console.error("Could not report the browser action result to AURA.", error);
        }
    }

    setInterval(pollAura, 1200);
    pollAura();
})();
