(() => {
    "use strict";
    const api = globalThis.browser ?? globalThis.chrome;
    let polling = false;

    function textOf(element) {
        return (element?.innerText || element?.textContent || "").replace(/\s+/g, " ").trim();
    }

    function pageType() {
        if (/\/rules\/?$/.test(location.pathname)) return "rules";
        if (/\/data\/?$/.test(location.pathname)) return "data";
        return null;
    }

    function capturePage(requestId) {
        const type = pageType();
        if (!type) throw new Error("Open a Firebase Realtime Database Data or Rules page first.");
        return {
            request_id: requestId,
            url: location.href,
            page_type: type,
            title: document.title,
            snapshot: (document.body.innerText || "").slice(0, 50000)
        };
    }

    function visible(element) {
        return Boolean(element?.isConnected && element.getClientRects().length);
    }

    function findUniqueNode(segment) {
        const matches = Array.from(document.querySelectorAll("span, div, button"))
            .filter(element => visible(element) && textOf(element) === segment);
        const leafMatches = matches.filter(element =>
            !Array.from(element.querySelectorAll("*")).some(child => textOf(child) === segment)
        );
        if (leafMatches.length !== 1) {
            throw new Error(
                leafMatches.length
                    ? `The key "${segment}" is ambiguous on the visible page; no change was made.`
                    : `Could not find the database key "${segment}" on the visible page.`
            );
        }
        return leafMatches[0];
    }

    function rowForSegment(segment) {
        let element = findUniqueNode(segment);
        for (let depth = 0; depth < 8 && element; depth += 1) {
            if (Array.from(element.querySelectorAll("button")).some(visible)) return element;
            element = element.parentElement;
        }
        throw new Error("Could not locate safe row controls for this database path.");
    }

    function rowForNode(path) {
        const rows = path.map(rowForSegment);
        for (let index = 1; index < rows.length; index += 1) {
            if (!rows[index - 1].contains(rows[index])) {
                throw new Error("Could not verify the full Firebase path in the visible tree; no change was made.");
            }
        }
        return rows[rows.length - 1];
    }

    function findActionButton(row, pattern) {
        const buttons = Array.from(row.querySelectorAll("button")).filter(visible);
        return buttons.find(button =>
            pattern.test(`${button.getAttribute("aria-label") || ""} ${button.title || ""}`)
        );
    }

    function setInput(input, value) {
        const setter = Object.getOwnPropertyDescriptor(
            input instanceof HTMLTextAreaElement
                ? HTMLTextAreaElement.prototype
                : HTMLInputElement.prototype,
            "value"
        )?.set;
        if (!setter) throw new Error("Firebase editor input is not supported.");
        setter.call(input, value);
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
    }

    async function applyDataAction(job) {
        if (pageType() !== "data" || location.href !== job.url) {
            throw new Error("The active Firebase Data page changed; inspect it again before editing.");
        }
        const row = rowForNode(job.path);
        if (job.operation === "delete") {
            const button = findActionButton(row, /delete|remove/i);
            if (!button) throw new Error("Firebase did not expose a Delete control for this node.");
            button.click();
            const dialog = Array.from(document.querySelectorAll('[role="dialog"]')).find(visible);
            const confirmButton = dialog && Array.from(dialog.querySelectorAll("button"))
                .find(button => visible(button) && /^delete$/i.test(textOf(button)));
            if (confirmButton) confirmButton.click();
            return;
        }

        if (job.operation === "add") {
            const button = findActionButton(row, /add|create/i);
            if (!button) throw new Error("Firebase did not expose an Add child control for this node.");
            button.click();
            const dialog = Array.from(document.querySelectorAll('[role="dialog"]')).find(visible);
            if (!dialog) throw new Error("Firebase's Add child editor did not open in a recognizable dialog.");
            const inputs = Array.from(dialog.querySelectorAll("input, textarea")).filter(visible);
            if (inputs.length < 2) {
                throw new Error("Could not identify Firebase's child-key and value fields; no value was submitted.");
            }
            const entries = Object.entries(job.value);
            if (entries.length !== 1) throw new Error("Add requires exactly one reviewed child key and value.");
            setInput(inputs[0], entries[0][0]);
            setInput(inputs[1], JSON.stringify(entries[0][1]));
            const addButton = Array.from(dialog.querySelectorAll("button"))
                .find(candidate => visible(candidate) && /^add$/i.test(textOf(candidate)));
            if (!addButton) throw new Error("Could not identify Firebase's Add confirmation button.");
            addButton.click();
            return;
        }

        if (job.operation === "set") {
            const valueText = JSON.stringify(job.value);
            const editable = Array.from(row.querySelectorAll("span, div"))
                .filter(element => visible(element) && textOf(element) !== path[path.length - 1]);
            if (editable.length !== 1) {
                throw new Error("Could not uniquely identify the value cell for this node; no change was made.");
            }
            editable[0].click();
            const input = Array.from(row.querySelectorAll("input, textarea")).find(visible);
            if (!input) throw new Error("Firebase did not open an inline value editor.");
            setInput(input, valueText);
            const saveButton = Array.from(row.querySelectorAll("button"))
                .find(button => visible(button) && /^(save|done)$/i.test(textOf(button)));
            if (saveButton) saveButton.click();
            else input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
            return;
        }
        throw new Error(`Unsupported Firebase operation: ${job.operation}`);
    }

    async function publishRules(job) {
        if (pageType() !== "rules" || location.href !== job.url) {
            throw new Error("The active Firebase Rules page changed; inspect it again before publishing.");
        }
        const editor = Array.from(document.querySelectorAll(
            '.monaco-editor textarea, .monaco-editor [contenteditable="true"], textarea[aria-label*="rule" i]'
        )).find(visible);
        if (!editor) throw new Error("Could not identify the visible Firebase Rules editor.");
        const publishButton = Array.from(document.querySelectorAll("button"))
            .find(button => visible(button) && /^publish$/i.test(textOf(button)));
        if (!publishButton) throw new Error("Could not identify Firebase's Publish Rules button.");
        editor.focus();
        document.execCommand("selectAll");
        const inserted = document.execCommand("insertText", false, job.rules);
        const editorRoot = editor.closest(".monaco-editor");
        const visibleText = editor instanceof HTMLTextAreaElement
            ? editor.value
            : editorRoot?.querySelector(".view-lines")?.textContent || "";
        const compact = value => value.replace(/\s+/g, "");
        if (!inserted || !compact(visibleText).includes(compact(job.rules))) {
            throw new Error(
                "Could not verify that the reviewed draft appeared in Firebase's Rules editor; nothing was published."
            );
        }
        publishButton.click();
    }

    async function handleJob(job) {
        if (job.action === "capture_firebase") {
            try {
                const result = await api.runtime.sendMessage({
                    type: "aura-firebase-capture",
                    payload: capturePage(job.request_id)
                });
                if (result?.error) throw new Error(result.error);
            } catch (error) {
                await api.runtime.sendMessage({
                    type: "aura-firebase-result",
                    payload: {
                        request_id: job.request_id,
                        status: "failed",
                        message: error.message
                    }
                });
            }
            return;
        }
        if (job.action !== "firebase_action") return;
        try {
            if (job.operation === "publish_rules") await publishRules(job);
            else await applyDataAction(job);
            await api.runtime.sendMessage({
                type: "aura-firebase-result",
                payload: {
                    request_id: job.request_id,
                    status: "applied",
                    message: `Firebase ${job.operation} action was dispatched to the visible Console controls. Verify the resulting value or rules in Firebase.`
                }
            });
        } catch (error) {
            await api.runtime.sendMessage({
                type: "aura-firebase-result",
                payload: {
                    request_id: job.request_id,
                    status: "failed",
                    message: error.message
                }
            });
        }
    }

    async function pollAura() {
        if (
            polling ||
            document.visibilityState !== "visible" ||
            location.hostname !== "console.firebase.google.com"
        ) return;
        polling = true;
        try {
            const response = await api.runtime.sendMessage({ type: "aura-poll" });
            if (response?.job) await handleJob(response.job);
        } catch (error) {
            console.debug("AURA Firebase connector:", error);
        } finally {
            polling = false;
        }
    }

    setInterval(pollAura, 1200);
    pollAura();
})();
