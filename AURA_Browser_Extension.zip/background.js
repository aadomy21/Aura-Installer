const api = globalThis.browser ?? globalThis.chrome;

async function getConnection() {
    const { auraConnection } = await api.storage.local.get("auraConnection");
    if (!auraConnection || !auraConnection.token || !auraConnection.port) {
        throw new Error("Pair the extension with AURA in extension settings first.");
    }
    return auraConnection;
}

async function requestAura(path, options = {}) {
    const connection = await getConnection();
    const url = `http://${connection.host}:${connection.port}${path}`;
    const response = await fetch(url, {
        ...options,
        headers: {
            "X-AURA-Token": connection.token,
            ...(options.body ? { "Content-Type": "application/json" } : {}),
            ...options.headers
        },
        cache: "no-store"
    });
    const payload = await response.json();
    if (!response.ok) {
        throw new Error(payload.error || `AURA connector returned HTTP ${response.status}.`);
    }
    return payload;
}

api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "aura-poll") {
        api.tabs.query({ active: true, lastFocusedWindow: true }).then(tabs => {
            if (tabs[0]?.id !== _sender.tab?.id) return { job: null };
            return requestAura("/api/poll");
        })
            .then(sendResponse)
            .catch(error => sendResponse({ error: error.message }));
        return true;
    }
    if (message?.type === "aura-capture") {
        requestAura("/api/form", {
            method: "POST",
            body: JSON.stringify(message.payload)
        })
            .then(sendResponse)
            .catch(error => sendResponse({ error: error.message }));
        return true;
    }
    if (message?.type === "aura-result") {
        requestAura("/api/result", {
            method: "POST",
            body: JSON.stringify(message.payload)
        })
            .then(sendResponse)
            .catch(error => sendResponse({ error: error.message }));
        return true;
    }
    if (message?.type === "aura-firebase-capture") {
        requestAura("/api/firebase/capture", {
            method: "POST",
            body: JSON.stringify(message.payload)
        })
            .then(sendResponse)
            .catch(error => sendResponse({ error: error.message }));
        return true;
    }
    if (message?.type === "aura-firebase-result") {
        requestAura("/api/firebase/result", {
            method: "POST",
            body: JSON.stringify(message.payload)
        })
            .then(sendResponse)
            .catch(error => sendResponse({ error: error.message }));
        return true;
    }
    if (message?.type === "aura-ping") {
        requestAura("/api/ping")
            .then(sendResponse)
            .catch(error => sendResponse({ error: error.message }));
        return true;
    }
    return false;
});
