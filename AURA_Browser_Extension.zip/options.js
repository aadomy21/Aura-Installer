const api = globalThis.browser ?? globalThis.chrome;
const input = document.getElementById("connectionInfo");
const status = document.getElementById("status");

api.storage.local.get("auraConnection").then(({ auraConnection }) => {
    if (auraConnection) input.value = JSON.stringify(auraConnection, null, 2);
});

document.getElementById("pairButton").addEventListener("click", async () => {
    status.textContent = "Checking connection…";
    try {
        const connection = JSON.parse(input.value);
        if (
            connection.host !== "127.0.0.1" ||
            !Number.isInteger(connection.port) ||
            connection.port < 1 ||
            connection.port > 65535 ||
            typeof connection.token !== "string" ||
            connection.token.length < 40
        ) {
            throw new Error("Pairing data must include AURA's loopback host, port, and token.");
        }
        await api.storage.local.set({ auraConnection: connection });
        const response = await api.runtime.sendMessage({ type: "aura-ping" });
        if (response?.error) throw new Error(response.error);
        status.textContent = "Connected to AURA. Supported: Google Forms and Firebase Realtime Database.";
    } catch (error) {
        status.textContent = `Could not pair: ${error.message}`;
    }
});
